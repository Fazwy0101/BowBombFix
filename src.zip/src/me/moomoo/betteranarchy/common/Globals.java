package me.moomoo.betteranarchy.common;

import me.moomoo.betteranarchy.bukkit.EntryPoint;

public interface Globals {

    default EntryPoint main() {
        return EntryPoint.getInstance();
    }

}
