package me.moomoo.betteranarchy.common.listeners;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.HashMap;

public class AntiDesync implements Listener {

    public HashMap<Player, Integer> a = new HashMap<>();
    public HashMap<Player, Integer> b = new HashMap<>();
    public static String[] c = {};

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        a.put(event.getPlayer(), 0);
        b.put(event.getPlayer(), 0);
    }

    @EventHandler
    public void onLeave(PlayerQuitEvent event) {
        a.put(event.getPlayer(), 0);
        b.put(event.getPlayer(), 0);
    }

    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        if(event.getPlayer().getVehicle() != null) {
            a.put(event.getPlayer(), 1);
            if(b.get(event.getPlayer()) > 3) {
                Bukkit.getServer().getConsoleSender().sendMessage(ChatColor.RED + "" + event.getPlayer() + " tried getting into godmode");
                event.getPlayer().leaveVehicle();
                a.put(event.getPlayer(), 0);
                b.put(event.getPlayer(), 0);
            }
        }
    }

}
