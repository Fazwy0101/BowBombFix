package me.moomoo.betteranarchy.common.listeners.protocol;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.events.ListenerPriority;
import com.comphenix.protocol.events.PacketAdapter;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.events.PacketEvent;
import com.comphenix.protocol.wrappers.EnumWrappers;
import me.moomoo.betteranarchy.common.Globals;
import org.bukkit.entity.Boat;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;

public class BoatFly implements Listener, Globals, Runnable {

    public BoatFly() {
        run();
    }

    @Override public void run() {
        ProtocolLibrary.getProtocolManager().addPacketListener(
                new PacketAdapter(main(), ListenerPriority.NORMAL, PacketType.Play.Client.USE_ENTITY) {
                    @Override
                    public void onPacketReceiving(PacketEvent event) {
                        Player player = event.getPlayer();
                        try {
                            PacketContainer packet = event.getPacket();
                            Entity target = packet.getEntityModifier(player.getWorld()).read(0);
                            EnumWrappers.EntityUseAction action = packet.getEntityUseActions().read(0);
                            EnumWrappers.Hand hand = packet.getHands().read(0);
                            if (action == EnumWrappers.EntityUseAction.INTERACT && target instanceof Boat && hand == EnumWrappers.Hand.MAIN_HAND) {
                                Boat boat = ( Boat ) target;
                                if (boat.getPassengers().contains(player)) {
                                    event.setCancelled(true);
                                }
                            }
                        } catch (Exception ignored) {

                        }
                    }
                }
                );
    }

}
