package me.moomoo.betteranarchy.common.listeners;

import me.moomoo.betteranarchy.common.Globals;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.util.Vector;

public class FastProjectile implements Listener, Globals {

    @EventHandler public void onArrow(ProjectileLaunchEvent event) {
        Projectile entity = event.getEntity();
        if (entity instanceof Arrow || entity instanceof Snowball || entity instanceof Egg || entity instanceof EnderPearl) {
            if (entity.getVelocity().lengthSquared() > 15) {
                entity.remove();
                event.setCancelled(true);
            }
        }
    }

}
