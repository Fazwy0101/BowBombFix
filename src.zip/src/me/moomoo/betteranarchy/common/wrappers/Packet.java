package me.moomoo.betteranarchy.common.wrappers;

public class Packet {
}
