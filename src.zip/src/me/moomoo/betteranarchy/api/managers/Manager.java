package me.moomoo.betteranarchy.api.managers;

public interface Manager<M> {

    M load();

    M unload();

}
