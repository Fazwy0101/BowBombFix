package me.moomoo.betteranarchy.api.managers.impl;

import me.moomoo.betteranarchy.api.managers.Manager;
import me.moomoo.betteranarchy.common.Globals;
import me.moomoo.betteranarchy.common.listeners.AntiDesync;
import me.moomoo.betteranarchy.common.listeners.FastProjectile;
import me.moomoo.betteranarchy.common.listeners.protocol.BoatFly;
import org.bukkit.event.Listener;

import java.util.ArrayList;
import java.util.Arrays;

public class Listeners extends ArrayList<Listener> implements Manager<Listeners>, Globals {

    @Override public Listeners load() {

        addAll(
                Arrays.asList(
                        new FastProjectile(),
                        new BoatFly(),
                        new AntiDesync()
                )
        );

        return this;
    }

    @Override public Listeners unload() {
        return this;
    }

}
