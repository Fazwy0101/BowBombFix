package me.moomoo.betteranarchy.bukkit;

import me.moomoo.betteranarchy.api.managers.impl.Listeners;
import org.bukkit.plugin.java.JavaPlugin;
import org.json.simplej.parser.JSONParser;

public final class EntryPoint extends JavaPlugin {

    private JSONParser parser;
    private static EntryPoint instance;
    private static Listeners listeners;

    @Override
    public void onEnable() {
        instance = this;
        parser = new JSONParser();
        listeners = new Listeners().load();
        listeners.forEach(
                e -> getServer().getPluginManager().registerEvents(e, this)
        );
    }

    @Override
    public void onDisable() {

    }

    public static EntryPoint getInstance() {
        return instance;
    }

}
